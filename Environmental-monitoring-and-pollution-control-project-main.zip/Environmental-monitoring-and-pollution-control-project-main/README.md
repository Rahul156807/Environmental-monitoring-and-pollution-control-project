

﻿# Internship Project 🚀

This repository contains the code and notebook for my environmental monitoring and pollution control internship project.

I have made this project in jupyter notebook using python and its various libraries

The name of this project is SmogSense

## 🔗 Links
[![linkedin](https://img.shields.io/badge/linkedin-0A66C2?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/swapnil-singh-24b7b1220?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=android_app)


## 🛠 Skills
Python 


## DATASETS

I have downloaded the datasets from kaggle



